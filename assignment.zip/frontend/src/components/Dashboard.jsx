import React, { useState, useEffect } from 'react'
import { getTasks, createTask } from '../api'

function Dashboard() {
  const [tasks, setTasks] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      getTasks(token).then(res => setTasks(res.data))
    }
  }, [])

  const handleCreate = async () => {
    const token = localStorage.getItem('token')
    const res = await createTask(token, { title, description })
    setTasks([...tasks, res.data])
  }

  return (
    <div>
      <h2>Dashboard</h2>
      <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
      <button onClick={handleCreate}>Add Task</button>
      <ul>
        {tasks.map(task => <li key={task.id}>{task.title}: {task.description}</li>)}
      </ul>
    </div>
  )
}
export default Dashboard
