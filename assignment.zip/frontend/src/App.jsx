import React, { useState } from 'react'
import Login from './components/Login'
import Register from './components/Register'
import Dashboard from './components/Dashboard'

function App() {
  const [page, setPage] = useState('login')
  return (
    <div>
      <h1>Assignment Demo</h1>
      <button onClick={() => setPage('login')}>Login</button>
      <button onClick={() => setPage('register')}>Register</button>
      <button onClick={() => setPage('dashboard')}>Dashboard</button>
      {page === 'login' && <Login />}
      {page === 'register' && <Register />}
      {page === 'dashboard' && <Dashboard />}
    </div>
  )
}
export default App
