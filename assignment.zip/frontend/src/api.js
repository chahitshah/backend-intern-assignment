import axios from 'axios'

const API_URL = 'http://127.0.0.1:8000'

export const register = (username, password) => axios.post(`${API_URL}/register`, {username, password})
export const login = (username, password) => axios.post(`${API_URL}/token`, new URLSearchParams({username, password}))
export const getTasks = (token) => axios.get(`${API_URL}/tasks/`, { headers: { Authorization: `Bearer ${token}` } })
export const createTask = (token, task) => axios.post(`${API_URL}/tasks/`, task, { headers: { Authorization: `Bearer ${token}` } })
